package com.mxgraph.costfunction;

import com.mxgraph.analysis.mxICostFunction;

public abstract class mxCostFunction implements mxICostFunction
{
}
