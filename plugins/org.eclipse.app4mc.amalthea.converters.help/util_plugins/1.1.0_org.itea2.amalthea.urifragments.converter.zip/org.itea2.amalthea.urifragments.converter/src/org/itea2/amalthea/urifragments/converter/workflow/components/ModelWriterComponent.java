package org.itea2.amalthea.urifragments.converter.workflow.components;

import java.io.IOException;

import org.apache.commons.logging.LogFactory;
import org.eclipse.emf.common.util.EList;
import org.eclipse.emf.ecore.resource.Resource;
import org.eclipse.emf.ecore.resource.ResourceSet;
import org.eclipse.emf.ecore.util.EcoreUtil;
import org.eclipse.emf.mwe.core.WorkflowContext;
import org.eclipse.emf.mwe.core.issues.Issues;
import org.eclipse.emf.mwe.core.monitor.ProgressMonitor;
import org.itea2.amalthea.workflow.base.AmaltheaWorkflow;


@SuppressWarnings("javadoc")
public class ModelWriterComponent extends AmaltheaWorkflow {

	@SuppressWarnings("javadoc")
	public ModelWriterComponent() {
		super();
		this.log = LogFactory.getLog("ModelWriter");
	}

	/**
	 * @see org.eclipse.emf.mwe.core.lib.AbstractWorkflowComponent#invokeInternal(org.eclipse.emf.mwe.core.WorkflowContext,
	 *      org.eclipse.emf.mwe.core.monitor.ProgressMonitor,
	 *      org.eclipse.emf.mwe.core.issues.Issues)
	 */
	@Override
	protected void invokeInternal(final WorkflowContext ctx, final ProgressMonitor monitor, final Issues issues) {
		
		this.log.info("Starting writer component...");
		try {
			
		Object resourceSet = ctx.get("ResourceSet");
		
		
		if(resourceSet instanceof ResourceSet){
			
			/*- As even the cross document references should be updated with UUID's, below line of code is added */
			EcoreUtil.resolveAll((ResourceSet)resourceSet);
			
			EList<Resource> resources = ((ResourceSet)resourceSet).getResources();
			
			for (Resource resource : resources) {
					resource.save(null);
				}
			}
		}
	  catch (IOException e) {
		e.printStackTrace();
	  }
		this.log.info("Finished writing model files");
	}

	/**
	 * @see org.eclipse.emf.mwe.core.lib.WorkflowComponentWithModelSlot#checkConfiguration(org.eclipse.emf.mwe.core.issues.Issues)
	 */
	@Override
	public void checkConfiguration(final Issues issues) {
	 
		super.checkConfiguration(issues);
	}
}
