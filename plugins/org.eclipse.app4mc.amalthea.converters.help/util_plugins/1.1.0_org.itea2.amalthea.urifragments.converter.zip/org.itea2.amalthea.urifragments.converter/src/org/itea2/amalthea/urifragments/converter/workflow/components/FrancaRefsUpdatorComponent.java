package org.itea2.amalthea.urifragments.converter.workflow.components;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;

import org.apache.commons.logging.LogFactory;
import org.eclipse.emf.common.util.EList;
import org.eclipse.emf.common.util.EMap;
import org.eclipse.emf.common.util.URI;
import org.eclipse.emf.ecore.EObject;
import org.eclipse.emf.ecore.EReference;
import org.eclipse.emf.ecore.impl.EObjectImpl;
import org.eclipse.emf.ecore.resource.Resource;
import org.eclipse.emf.ecore.resource.ResourceSet;
import org.eclipse.emf.ecore.util.EcoreUtil;
import org.eclipse.emf.mwe.core.WorkflowContext;
import org.eclipse.emf.mwe.core.issues.Issues;
import org.eclipse.emf.mwe.core.monitor.ProgressMonitor;
import org.itea2.amalthea.model.common.CommonFactory;
import org.itea2.amalthea.model.common.StringObject;
import org.itea2.amalthea.model.common.Value;
import org.itea2.amalthea.model.components.FInterfacePort;
import org.itea2.amalthea.model.components.impl.FInterfacePortImpl;
import org.itea2.amalthea.workflow.base.AmaltheaWorkflow;


@SuppressWarnings("javadoc")
public class FrancaRefsUpdatorComponent extends AmaltheaWorkflow {


	@SuppressWarnings("javadoc")
	public FrancaRefsUpdatorComponent() {
		super();
		this.log = LogFactory.getLog("Franca interface updator");
	}

	/**
	 * @see org.eclipse.emf.mwe.core.lib.AbstractWorkflowComponent#invokeInternal(org.eclipse.emf.mwe.core.WorkflowContext,
	 *      org.eclipse.emf.mwe.core.monitor.ProgressMonitor,
	 *      org.eclipse.emf.mwe.core.issues.Issues)
	 */
	@Override
	protected void invokeInternal(final WorkflowContext ctx, final ProgressMonitor monitor, final Issues issues) {
		
		this.log.info("Starting to convert Franca element references as custom attributes...");
		
		Object resourceSet = ctx.get("ResourceSet");
		
		List<EObject> fInterfacePorts=new ArrayList<EObject>();
		
		if(resourceSet instanceof ResourceSet){
			
			EList<Resource> resources = ((ResourceSet)resourceSet).getResources();
			
			for (Resource resource : resources) {

				EList<EObject> contents = resource.getContents();
				
				if(contents.size()>0){
					
					EObject rootObject = contents.get(0);
					
					/*-looping through all the objects in Amalthea Model file*/
					
					for (final Iterator<EObject> classIterator = EcoreUtil.getAllContents(Collections.singleton(rootObject)); classIterator
							.hasNext();) {

						final EObject eObject = classIterator.next();
						
						if(eObject instanceof FInterfacePortImpl){

							/*- Adding FInterfacePortImpl element to the list */
							fInterfacePorts.add(eObject);
							
							
						}
						

				 
					}
					
				}

			}
		}

		/*- looping through the FinterfacePortImpl elements and removing the corresponding Franca elements inside them */
		
		for (EObject eObject : fInterfacePorts) {
			removeFrancaReference(eObject);
			
		}
		
		
		this.log.info("Finished updating Franca element references..");
	}

	/**
	 * This method is responsible for removing Franca reference and adding the content of it as a CustomProperty to the Component element
	 * @param fInterfacePort object of FInterfacePortImpl
	 */
	private void removeFrancaReference(final EObject fInterfacePort) {
		
		EList<EReference> eAllReferences = ((EObject)fInterfacePort).eClass().getEAllReferences();
		
		for (EReference eReference : eAllReferences) {
			
			if(eReference.getName().equals("interface")){

				/*- explicitly proxy is not resolved here, otherwise it will throw an exception due to Franca elements*/
				
				  Object eGet = ((EObject)fInterfacePort).eGet(eReference,false);
				  
				  if(eGet instanceof EObjectImpl){
					  
					  URI eProxyURI = ((EObjectImpl)eGet).eProxyURI();
					  
					  String proxy=eProxyURI.toString().replace("platform:/resource/org.itea2.amalthea.urifragments.converter/models/", "");
					  
						  /*- URI Fragment of Franca element is set as Custom property */
						  
						  EMap<String, Value> customProperties = ((FInterfacePort)fInterfacePort).getCustomProperties();

						  StringObject value = CommonFactory.eINSTANCE.createStringObject();
						  value.setValue(proxy);

						  customProperties.put("Franca interface", value);
 
					  
					  /*- removing the reference to Franca element */
					  EcoreUtil.remove(fInterfacePort,eReference,eGet);
				  }
				
				
			}
		}
	}

	/**
	 * @see org.eclipse.emf.mwe.core.lib.WorkflowComponentWithModelSlot#checkConfiguration(org.eclipse.emf.mwe.core.issues.Issues)
	 */
	@Override
	public void checkConfiguration(final Issues issues) {
	 
		super.checkConfiguration(issues);
	}
	
	
}
