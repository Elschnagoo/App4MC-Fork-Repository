package org.itea2.amalthea.urifragments.converter.workflow.components;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import org.apache.commons.logging.LogFactory;
import org.eclipse.emf.common.util.URI;
import org.eclipse.emf.ecore.resource.Resource;
import org.eclipse.emf.ecore.resource.ResourceSet;
import org.eclipse.emf.ecore.resource.impl.ResourceSetImpl;
import org.eclipse.emf.mwe.core.WorkflowContext;
import org.eclipse.emf.mwe.core.issues.Issues;
import org.eclipse.emf.mwe.core.monitor.ProgressMonitor;
import org.itea2.amalthea.model.central.AMALTHEA;
import org.itea2.amalthea.model.common.resource.AmaltheaResourceFactory;
import org.itea2.amalthea.workflow.base.AmaltheaWorkflow;

/**
 * Reads a list of configured files and loads them into the
 * {@link WorkflowContext} as {@link AMALTHEA} model. The model content
 * available is a copy, so modifications to it does not affect the original
 * file.
 */
public class ModelReaderComponent extends AmaltheaWorkflow {

	private final List<String> fileNames = new ArrayList<String>();
	
	@SuppressWarnings("javadoc")
	public ModelReaderComponent() {
		super();
		this.log = LogFactory.getLog("ModelReader");
	}

	/**
	 * @see org.eclipse.emf.mwe.core.lib.AbstractWorkflowComponent#invokeInternal(org.eclipse.emf.mwe.core.WorkflowContext,
	 *      org.eclipse.emf.mwe.core.monitor.ProgressMonitor,
	 *      org.eclipse.emf.mwe.core.issues.Issues)
	 */
	@Override
	protected void invokeInternal(final WorkflowContext ctx, final ProgressMonitor monitor, final Issues issues) {
		this.log.info("Starting to load Amalthea model files...");
		final ResourceSet resSet = new ResourceSetImpl();
		AmaltheaResourceFactory amaltheaResourceFactory = new AmaltheaResourceFactory();
		resSet.getResourceFactoryRegistry().getExtensionToFactoryMap().put("amxmi", amaltheaResourceFactory);
		resSet.getResourceFactoryRegistry().getExtensionToFactoryMap().put("amxmi-propertyconstraints", amaltheaResourceFactory);
		resSet.getResourceFactoryRegistry().getExtensionToFactoryMap().put("amxmi-stimuli", amaltheaResourceFactory);
		resSet.getResourceFactoryRegistry().getExtensionToFactoryMap().put("amxmi-sw", amaltheaResourceFactory);
		resSet.getResourceFactoryRegistry().getExtensionToFactoryMap().put("amxmi-config", amaltheaResourceFactory);
		resSet.getResourceFactoryRegistry().getExtensionToFactoryMap().put("amxmi-constraints", amaltheaResourceFactory);
		resSet.getResourceFactoryRegistry().getExtensionToFactoryMap().put("amxmi-events", amaltheaResourceFactory);
		resSet.getResourceFactoryRegistry().getExtensionToFactoryMap().put("amxmi-mapping", amaltheaResourceFactory);
		resSet.getResourceFactoryRegistry().getExtensionToFactoryMap().put("amxmi-os", amaltheaResourceFactory);
		resSet.getResourceFactoryRegistry().getExtensionToFactoryMap().put("amxmi-components", amaltheaResourceFactory);
		resSet.getResourceFactoryRegistry().getExtensionToFactoryMap().put("amxmi-hw", amaltheaResourceFactory);
		
		for (final String filename : getFileNames()) {
			
			try {
				this.log.info("Reading file: " + filename);
				final Resource res = resSet.createResource(URI.createURI(filename));
				res.load(null);
				ctx.set("ResourceSet", resSet);
			}
			catch (final IOException e) {
				issues.addError(this, "Error at loading files!", null, e, null);
			}
		}
		this.log.info("Finished loading Amalthea models");
	}

	/**
	 * @see org.eclipse.emf.mwe.core.lib.WorkflowComponentWithModelSlot#checkConfiguration(org.eclipse.emf.mwe.core.issues.Issues)
	 */
	@Override
	public void checkConfiguration(final Issues issues) {
		if (this.fileNames.isEmpty()) {
			issues.addError(this, "No filenames configured to read!");
		}
		super.checkConfiguration(issues);
	}

	/**
	 * @return the fileNames
	 */
	public List<String> getFileNames() {
		return this.fileNames;
	}

	/**
	 * @param fileName
	 *            the fileName to set
	 */
	public void addFileName(final String fileName) {
		this.fileNames.add(fileName);
	}

}
