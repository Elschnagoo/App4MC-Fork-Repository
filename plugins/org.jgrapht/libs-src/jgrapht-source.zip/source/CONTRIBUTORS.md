## Contributors ##

JGraphT wouldn't be the library it is today without the source contributions and suggestions made by the authors:

- [Barak Naveh](http://sourceforge.net/users/barak_naveh/) (project founder)
- [John V Sichi](http://sourceforge.net/users/perfecthash/) (current project administrator)
- [Liviu Rau](http://sourceforge.net/users/liviu_aurelian/)
- [Nathan Fiedler](http://www.bluemarsh.com/personal/index.html)
- [Michael Behrisch](http://sourceforge.net/users/behrisch/)
- [Linda Buisman](http://sourceforge.net/users/linda_buisman/)
- Erik Postma
- Mikael Hansen
- Avner Linder
- Marden Neubert
- [Christian Soltenborn](http://sourceforge.net/users/csoltenborn/)
- [Christian Hammer](http://sourceforge.net/users/hammerc/)
- Ewgenij Proschak
- [Hartmut Benz](http://sourceforge.net/users/ivins/)
- [Charles Fry](http://frogcircus.org/)
- Guillaume Boulmier
- Carl Anderson
- Khanh Vu
- Aaron Harnly
- Dimitrios Michail
- Welson Sun
- Trevor Harmon
- David Black-Schaffer
- Vinayak Borkar
- Andrew Berman
- Lucas Scharenbroich
- Hookahey
- Tim Shearouse
- Holger Brandl
- Ilya Razenshteyn
- Peter Giles
- Andrew Newell
- Tim Engler
- Tom Larkworthy
- Soren Davidsen
- Andrea Pagani
- Tom Conerly
- Michele Mancioppi
- Adrian Marte
- Assaf Mizrachi
- Harshal Vora
- Matt Sarjent
- Robby McKilliam
- Yuriy Nakonechnyy
- Andreas Schnaiter
- Owen Jacobson
- Alejandro R. Lopez del Huerto
- Vladimir Kostyukov
- Ernst de Ridder
- Joris Kinable
- Michal Pasieka
- Alexey Kudinkin
- Adam Gouge
- Nikolay Ognyanov
- Graham Hill (AzrgExplorers)
- Leo Crawford
- Isaac Kleinman
- Sebastian Hubenschmid
- JeanYves Tinevez
- Oliver Kopp
- https://github.com/javierj

(if we have missed your name on this list, please email us to get it fixed).

Other people have also helped in different ways: reporting bugs,requesting features, commenting, and by merely asking very good questions.

Many thanks to all of you.
