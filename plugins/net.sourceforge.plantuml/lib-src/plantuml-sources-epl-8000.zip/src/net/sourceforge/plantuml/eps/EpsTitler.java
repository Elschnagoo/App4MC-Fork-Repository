/* ========================================================================
 * PlantUML : a free UML diagram generator
 * ========================================================================
 *
 * (C) Copyright 2009-2014, Arnaud Roques
 *
 * Project Info:  http://plantuml.sourceforge.net
 * 
 * This file is part of PlantUML.
 *
 * THE ACCOMPANYING PROGRAM IS PROVIDED UNDER THE TERMS OF THIS ECLIPSE PUBLIC
 * LICENSE ("AGREEMENT"). [Eclipse Public License - v 1.0]
 * 
 * ANY USE, REPRODUCTION OR DISTRIBUTION OF THE PROGRAM CONSTITUTES
 * RECIPIENT'S ACCEPTANCE OF THIS AGREEMENT.
 * 
 * You may obtain a copy of the License at
 * 
 * http://www.eclipse.org/legal/epl-v10.html
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * 
 *
 * Original Author:  Arnaud Roques
 */
package net.sourceforge.plantuml.eps;

import java.awt.Font;
import java.awt.geom.Dimension2D;
import java.io.IOException;
import java.util.List;
import java.util.StringTokenizer;

import net.sourceforge.plantuml.SpriteContainerEmpty;
import net.sourceforge.plantuml.cucadiagram.Display;
import net.sourceforge.plantuml.graphic.FontConfiguration;
import net.sourceforge.plantuml.graphic.HorizontalAlignment;
import net.sourceforge.plantuml.graphic.HtmlColor;
import net.sourceforge.plantuml.graphic.TextBlock;
import net.sourceforge.plantuml.graphic.TextBlockUtils;
import net.sourceforge.plantuml.graphic.VerticalPosition;
import net.sourceforge.plantuml.ugraphic.ColorMapper;
import net.sourceforge.plantuml.ugraphic.UFont;
import net.sourceforge.plantuml.ugraphic.UTranslate;
import net.sourceforge.plantuml.ugraphic.eps.UGraphicEps;

public final class EpsTitler {

	private final List<? extends CharSequence> text;
	private final HorizontalAlignment horizontalAlignment;
	private final VerticalPosition verticalPosition;
	private final int margin;
	private final TextBlock textBloc;
	private final EpsStrategy epsStrategy;
	private final ColorMapper colorMapper;

	public EpsTitler(ColorMapper colorMapper, EpsStrategy epsStrategy, HtmlColor textColor,
			List<? extends CharSequence> text, int fontSize, String fontFamily,
			HorizontalAlignment horizontalAlignment, VerticalPosition verticalPosition, int margin) {
		this.text = text;
		this.colorMapper = colorMapper;
		this.epsStrategy = epsStrategy;
		this.horizontalAlignment = horizontalAlignment;
		this.verticalPosition = verticalPosition;
		this.margin = margin;
		if (text == null || text.size() == 0) {
			textBloc = null;
		} else {
			final UFont normalFont = new UFont(fontFamily, Font.PLAIN, fontSize);
			textBloc = TextBlockUtils.create(Display.create(text), new FontConfiguration(normalFont, textColor),
					HorizontalAlignment.LEFT, new SpriteContainerEmpty());
		}
	}

	public double getHeight() {
		if (textBloc == null) {
			return 0;
		}
		return textBloc.calculateDimension(new UGraphicEps(colorMapper, epsStrategy).getStringBounder()).getHeight()
				+ margin;
	}

	public String addTitleEps(String eps) throws IOException {
		if (text == null || text.size() == 0) {
			return eps;
		}

		final int idx = eps.indexOf("%%BoundingBox:");
		if (idx == -1) {
			throw new IllegalArgumentException();
		}
		final StringTokenizer st = new StringTokenizer(eps.substring(idx + "%%BoundingBox:".length()), " \n\t\r");
		final int x1 = Integer.parseInt(st.nextToken());
		final int y1 = Integer.parseInt(st.nextToken());
		final int x2 = Integer.parseInt(st.nextToken());
		final int y2 = Integer.parseInt(st.nextToken());
		assert x2 >= x1;
		assert y2 >= y1;

		final double width = x2 - x1;
		final double height = y2 - y1;

		final UGraphicEps uGraphicEps = new UGraphicEps(colorMapper, epsStrategy);
		final Dimension2D dimText = textBloc.calculateDimension(uGraphicEps.getStringBounder());
		final double xpos;

		if (horizontalAlignment == HorizontalAlignment.LEFT) {
			xpos = 2;
		} else if (horizontalAlignment == HorizontalAlignment.RIGHT) {
			xpos = width - dimText.getWidth() - 2;
		} else if (horizontalAlignment == HorizontalAlignment.CENTER) {
			xpos = (width - dimText.getWidth()) / 2;
		} else {
			xpos = 0;
			assert false;
		}

		final double yText;

		if (verticalPosition == VerticalPosition.TOP) {
			yText = 0;
		} else {
			yText = height + margin;
		}

		textBloc.drawU(uGraphicEps.apply(new UTranslate(xpos, yText)));

		final double yImage;
		if (verticalPosition == VerticalPosition.TOP) {
			yImage = dimText.getHeight();
		} else {
			yImage = 0;
		}

		uGraphicEps.drawEps(eps, 0, yImage);

		uGraphicEps.close();
		return uGraphicEps.getEPSCode();

	}

}
