/* ========================================================================
 * PlantUML : a free UML diagram generator
 * ========================================================================
 *
 * (C) Copyright 2009-2014, Arnaud Roques
 *
 * Project Info:  http://plantuml.sourceforge.net
 * 
 * This file is part of PlantUML.
 *
 * THE ACCOMPANYING PROGRAM IS PROVIDED UNDER THE TERMS OF THIS ECLIPSE PUBLIC
 * LICENSE ("AGREEMENT"). [Eclipse Public License - v 1.0]
 * 
 * ANY USE, REPRODUCTION OR DISTRIBUTION OF THE PROGRAM CONSTITUTES
 * RECIPIENT'S ACCEPTANCE OF THIS AGREEMENT.
 * 
 * You may obtain a copy of the License at
 * 
 * http://www.eclipse.org/legal/epl-v10.html
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * 
 *
 * Original Author:  Arnaud Roques
 */
package net.sourceforge.plantuml.command;

import java.util.Iterator;
import java.util.List;

public enum MultilinesStrategy {
	REMOVE_STARTING_QUOTE, KEEP_STARTING_QUOTE;

	public List<String> filter(List<String> lines) {
		if (this == REMOVE_STARTING_QUOTE) {
			filterQuote(lines);
		}
		return lines;
	}

	private void filterQuote(List<String> lines) {
		for (final Iterator<String> it = lines.iterator(); it.hasNext();) {
			final String s = it.next();
			if (hasStartingQuote(s)) {
				it.remove();
			}
		}
	}

	private boolean hasStartingQuote(String s) {
		return s.trim().startsWith("\'");
	}
}
